Calicia Perea 
HW3- Machine Learning 
Readme.txt

In this project, we will be using the sklearn library to learn different classification models and report 
the models performance on the testing and training data. In our output we are also adjusting one hyper-paremeter based on the specic classifier 
and reporting its performance. We will also be reporting the testing time. 

I used Google Colab for my hw3.py. You should be able to run it as a normal Google Colab file. 