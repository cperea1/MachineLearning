{\rtf1\ansi\ansicpg1252\cocoartf2707
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww12620\viewh6060\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs48 \cf0 Calicia Perea\
Machine Learning- HW1\
\
Renamed iris.data to \'93iris.data.csv\'94 to be able to use file path in document. File should have the file path to read in using pandas. There is no change to the dataset, is the same. Does not contain new coloumns. \
\
Used Google Colab environment. }